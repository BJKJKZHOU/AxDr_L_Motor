import sys,json,time,hashlib,yaml
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/home/zhouheng/GitHub_Pro/AxDr_L_Motor')
sys.path.insert(0,str(ROOT/'tools'))
from identification_test import *
from ident_swd_trace import openocd_connect
OUT=Path('/tmp/trajectory_hw_20261007')
PORT='/dev/serial/by-id/usb-STMicroelectronics_STM32_USB_Device_000000000001-if00'
PARAM_FORMAT.update({1:'<b',3:'<i'})
TYPES={'f32':PARAM_FLOAT,'u8':PARAM_U8,'i8':1,'u32':PARAM_U32,'i32':3}
OBJECTS=yaml.safe_load((ROOT/'Parameter/parameter.yaml').read_text())['objects']
def persistent(c,old=False):
    d={}
    for n,p in OBJECTS.items():
        if not p.get('persistent'):continue
        try:d[n]=c.parameter_read(p['id'],TYPES[p['type']])
        except RuntimeError as e:
            if old and n=='PARAM_MOTION_TE_RATE' and 'ERR_VAR_ID' in str(e):continue
            raise
    return d
def state(c):
    return {n:c.parameter_read(p,t) for n,p,t in [('state',PARAM_MOTOR_STATE,PARAM_U8),('ready',PARAM_ENCODER_READY,PARAM_U8),('valid',PARAM_ENCODER_VALID,PARAM_U8),('fault',PARAM_ENCODER_FAULT,PARAM_U8),('error',PARAM_EVENT_ERROR,PARAM_U32),('trip',PARAM_EVENT_TRIP,PARAM_U32),('vbus',PARAM_ADC_VBUS,PARAM_FLOAT)]}
def client():
    s=serial.Serial(PORT,115200,timeout=.003,write_timeout=1)
    s.reset_input_buffer()
    return s,IdentificationClient(s,SimpleNamespace(timeout=2))
if __name__=='__main__':
    r={};s=None;t=None;p=None;l=None
    try:
        s,c=client();r['before_state']=state(c)
        assert r['before_state']['state']==0,r
        assert not r['before_state']['error'] and not r['before_state']['trip'],r
        r['before']=persistent(c,True)
        r['before_mode']=c.parameter_read(PARAM_MOTOR_MODE,PARAM_U8)
        r['before_commands']={str(k):c.parameter_read(k,PARAM_FLOAT) for k in (PARAM_TARGET_SPEED,PARAM_TARGET_TORQUE)}
        (OUT/'flash.json').write_text(json.dumps(r,indent=2))
        t,p,l=openocd_connect(ROOT/'openocd.cfg',OUT/'flash_swd.json')
        t.sock.settimeout(30);t.command('poll');t.ensure_running()
        assert not t.words(0x40012c44,1)[0]&32768
        for name,addr,size in [('before_nvs',0x0807c000,0x4000),('before_application',0x08000000,0x7c000)]:
            path=OUT/(name+'.bin');assert not path.exists()
            r[name]=t.command(f'dump_image {path} {addr:#x} {size:#x}')
            assert path.stat().st_size==size
        s.close();s=None
        r['program']=t.command('program build/Release/AxDr_L_Motor.elf verify reset')
        assert 'verified' in r['program'].lower(),r['program']
        time.sleep(2);t.command('poll');t.ensure_running()
        s,c=client();r['after']=persistent(c)
        changed={k:[v,r['after'].get(k)] for k,v in r['before'].items() if r['after'].get(k)!=v}
        assert not changed,changed
        assert r['after']['PARAM_MOTION_TE_RATE']==r['before'].get('PARAM_MOTION_TE_RATE',0)
        r['after_state']=state(c);r['BDTR']=t.words(0x40012c44,1)[0]
        assert r['after_state']['state']==0 and not r['BDTR']&32768
        assert r['after_state']['ready']==1 and r['after_state']['valid']==1
        assert not any(r['after_state'][k] for k in ('fault','error','trip'))
        r['nvs_after_dump']=t.command(f'dump_image {OUT}/after_nvs.bin 0x0807c000 0x4000')
        assert (OUT/'after_nvs.bin').read_bytes()==(OUT/'before_nvs.bin').read_bytes()
        r['sha256']=hashlib.sha256((ROOT/'build/Release/AxDr_L_Motor.elf').read_bytes()).hexdigest()
        r['completed']=True
        print(json.dumps({k:r[k] for k in ('after_state','sha256','completed')},indent=2))
    except BaseException as e:
        r['error']=repr(e);raise
    finally:
        (OUT/'flash.json').write_text(json.dumps(r,indent=2))
        if s:s.close()
        if t:t.close()
        if p:p.terminate();p.wait(timeout=3)
        if l:l.close()
